package tad.pilha;

public class PilhaVaziaException extends Exception {
	public PilhaVaziaException() {
		super("pilha vazia!!");
	}
}
