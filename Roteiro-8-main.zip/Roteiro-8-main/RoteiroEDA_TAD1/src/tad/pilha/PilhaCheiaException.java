package tad.pilha;

public class PilhaCheiaException extends Exception {

	public PilhaCheiaException() {
		super("pilha cheia!");
	}
	
}
