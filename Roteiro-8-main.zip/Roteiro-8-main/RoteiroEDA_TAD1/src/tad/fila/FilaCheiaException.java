package tad.fila;

public class FilaCheiaException extends Exception {
	public FilaCheiaException() {
		super("fila cheia");
	}

}
