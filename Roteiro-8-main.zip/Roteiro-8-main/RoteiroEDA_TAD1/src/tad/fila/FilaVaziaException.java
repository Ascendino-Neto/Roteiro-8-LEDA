package tad.fila;

public class FilaVaziaException extends Exception {

	public FilaVaziaException() {

		super("fila vazia!");
	}
}